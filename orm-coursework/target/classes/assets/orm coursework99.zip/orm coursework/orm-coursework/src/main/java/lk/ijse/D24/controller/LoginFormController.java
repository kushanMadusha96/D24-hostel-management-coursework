package lk.ijse.D24.controller;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.D24.bo.BoFactory;
import lk.ijse.D24.bo.cutom.RegisterBO;

import java.io.IOException;

public class LoginFormController {

    public TextField txtUserName;
    public TextField txtPaswordOnAction;
    public AnchorPane loginPane;

    RegisterBO registerBO = (RegisterBO) BoFactory.getBoFactory().getBo(BoFactory.BoTypes.REGISTER);

    public void btnLoginOnAction(ActionEvent event) {
        String userName = txtUserName.getText();
        String password = txtPaswordOnAction.getText();

        boolean isThere = registerBO.isThereUser(userName, password);

        if( true == isThere) {
            try {
                Parent root = FXMLLoader.load(getClass().getResource("/view/home_form.fxml"));
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                stage.centerOnScreen();
                new Alert(Alert.AlertType.CONFIRMATION, "login successfully...").show();
            } catch (IOException ioException) {
                new Alert(Alert.AlertType.WARNING, "something went wrong, please try again...").show();
            }
        }else {
            new Alert(Alert.AlertType.ERROR, "can't find user! please register...").show();
        }
    }

    public void btnRegisterOnAction(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/register_form.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            stage.centerOnScreen();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
}
