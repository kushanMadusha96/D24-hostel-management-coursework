package lk.ijse.D24.dao.impl;

import lk.ijse.D24.dao.FactoryConfiguration;
import lk.ijse.D24.dao.QueryDAO;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class QueryDAOImpl implements QueryDAO {

}
