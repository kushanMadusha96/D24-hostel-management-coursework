package lk.ijse.D24.entity;

public class Payment {
    private String resId;
    private String remainingKeyMoneyAmount;
}
