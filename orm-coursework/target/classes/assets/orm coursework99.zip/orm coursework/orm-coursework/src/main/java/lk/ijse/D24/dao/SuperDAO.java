package lk.ijse.D24.dao;

public interface SuperDAO {
}
