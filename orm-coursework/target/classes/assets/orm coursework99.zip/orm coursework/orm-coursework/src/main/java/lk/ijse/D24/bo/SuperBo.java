package lk.ijse.D24.bo;

public interface SuperBo {
}
